<?php

defined('_JEXEC') or die('Restricted access'); // no direct access
$templateUrl = $this->baseurl . '/templates/' . $this->template;
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
<jdoc:include type="head" />
<link rel="stylesheet" href="<?php echo $templateUrl; ?>/css/reset.css" />
<!--<link rel="stylesheet" href="<?php echo $templateUrl; ?>/css/template.css" />-->
<link rel="stylesheet" href="<?php echo $templateUrl; ?>/css/styles.css" />

<!--[if lt IE 9]>
  <script>
    document.createElement('header');
    document.createElement('nav');
    document.createElement('section');
    document.createElement('article');
    document.createElement('aside');
    document.createElement('footer');
    document.createElement('hgroup');
  </script>
<![endif]-->
</head>
<body>
  <header class="clearfix">
    <section class="logo-in clearfix">
      <a href="<?php echo $this->baseurl?>"><img class="logo" src="images/logo.png" alt="logo"></a>
      <h1><a href="<?php echo $this->baseurl?>">ԿԱԹՆԱՄԹԵՐՔ ԱՐՏԱԴՐՈՂՆԵՐԻ ՄԻՈՒԹՅՈՒՆ</a></h1>  
    </section><!--logo-in-->
    <section class="header-right">
	  <section class="language">
		<jdoc:include type="modules" name="language" style="none" /> 
	  </section><!--language-->		
      <div class="find"></div>
        <jdoc:include type="modules" name="search" style="none" />
      <nav class="short-navigation clearfix">
      <jdoc:include type="modules" name="menu-main" style="none" />  
      </nav>
    </section><!--header-right-->
  </header><!--header-->
  <section id="container" class="clearfix">
    <nav class="navigation clearfix">
      <jdoc:include type="modules" name="menu-top" style="none" />
    </nav><!--navigation-->
    <section class="container-on clearfix">
	<?php if ($this->countModules('slideshow')) : ?>
            <section class="slideshow">
                        <jdoc:include type="modules" name="slideshow" style="none" />
            </section> 
			<?php endif; ?>
      <article class="info clearfix">
        <section class="content">
          <jdoc:include type="component" />
		  <section class="video">
				<jdoc:include type="modules" name="bottom-video" style="xhtml_unlink" />
			</section>
        </section><!--content-->
        <aside class="right">
                    <jdoc:include type="modules" name="right" style="xhtml_link" />
        </aside><!--right-->
      </article>
    </section><!--container-on-->
  </section><!--container-->
  <footer class="clearfix">
    <section class="footer-in">
      <p class="footer-left">Copyright 2013</p>
      <p class="footer-right">design by <a href=""><img title="fractal" src="images/fractal-logo.png" alt="fractal-logo" /></a> crative</p>
    </section><!--footer-in-->
  </footer><!--footer-->
</body>
</html>